/**
 * auth.js — Handles ONLY the NEW login steps:
 *   1. Verification type selection ("Where to send code?")
 *   2. CAPTCHA solving (Groq AI vision)
 *   3. OTP auto-fill from Gmail
 *
 * Email, PIN, country selection = handled by original fetch.js (unchanged)
 */
(async function () {
    'use strict';

    // ── Groq API key is entered by users in the extension popup ────────────────
    // No hardcoded key — each user supplies their own via the popup input field.
    // ─────────────────────────────────────────────────────────────────────────

    function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

    function toast(html, duration = 4000) {
        if (typeof Swal === 'undefined') return;
        Swal['fire']({
            'toast': !![],
            'position': 'bottom-start',
            'timer': duration,
            'showConfirmButton': ![],
            'timerProgressBar': !![],
            'background': 'rgba(15,15,15,0.92)',
            'html': '<div style="font-size:13px;font-family:sans-serif;">' + html + '</div>'
        });
    }

    function simulateInput(el, value) {
        el.focus();
        // Must use React's native value setter — direct assignment is ignored by React
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(el, value);
        // Fire all events React listens to
        el.dispatchEvent(new Event('input',  { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keydown',  { bubbles: true, key: 'a' }));
        el.dispatchEvent(new KeyboardEvent('keyup',    { bubbles: true, key: 'a' }));
        el.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, key: 'a' }));
    }

    function simulateClick(el) {
        if (!el) return;
        ['mousedown', 'mouseup', 'click'].forEach(type => {
            el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
        });
    }

    async function waitFor(selector, timeout = 8000) {
        const t = Date.now();
        while (Date.now() - t < timeout) {
            const el = document.querySelector(selector);
            if (el) return el;
            await sleep(250);
        }
        return null;
    }

    // ── Only detect the 3 new steps — never touch email/PIN/country ──────────
    let _verifyTypeDone = false; // prevent re-firing verify-type in a loop

    function detectStep() {
        const text = document.body.innerText || '';
        const title = document.title || '';

        // Skip if Swal popup is open
        if (document.querySelector('.swal2-container.swal2-shown')) return null;

        // ── CAPTCHA: detect by visible square image grid (works even in shadow DOM / widgets)
        const captchaImgs = [...document.querySelectorAll('img')].filter(img => {
            const r = img.getBoundingClientRect();
            return r.width >= 70 && r.width <= 330 &&
                   r.height >= 70 && r.height <= 330 &&
                   r.top > 30 && img.naturalWidth > 0 && img.src.startsWith('http');
        });
        if (captchaImgs.length >= 6) return 'captcha';
        // "Let's confirm you are human" — BEGIN button pre-screen (new Amazon 2026 flow)
        const _beginBtn = [...document.querySelectorAll('button')].find(b =>
            /^begin/i.test(b.textContent.trim()) && b.getBoundingClientRect().width > 0);
        if (_beginBtn || text.includes('Complete the security check before continuing')) return 'begin-captcha';
        if (text.includes("confirm you are human")) return 'captcha';

        // ── OTP entry page
        if (text.includes('verification code has been sent') || title.includes('Verify code')) return 'otp';

        // ── Verification type — only fire ONCE per session
        if (!_verifyTypeDone && text.includes('Where should we send your verification code')) return 'verify-type';

        return null;
    }

    // ── Verification type: select Email → Send ────────────────────────────────
    async function handleVerifyType() {
        _verifyTypeDone = true; // lock — never re-fire until page reloads
        await sleep(800);
        const radios = [...document.querySelectorAll('input[type="radio"], [role="radio"]')];
        const emailRadio = radios.find(r => {
            const label = r.closest('label') || r.parentElement;
            return label && label.textContent.toLowerCase().includes('email');
        });
        if (emailRadio) simulateClick(emailRadio);
        await sleep(400);

        const sendBtn = [...document.querySelectorAll('button')]
            .find(b => b.textContent.includes('Send verification code'));
        if (sendBtn) {
            toast('📧 <b style="color:#00d4ff;">Sending verification code to your email...</b>');
            simulateClick(sendBtn);
        }
    }

    // ── CAPTCHA solver ──────────────────────────────────────────────────────────
    // Flow: detect → screenshot → Groq → click cells + Confirm (1 debugger session)
    //       → wait for "Incorrect" or page change → retry ONLY after fresh images


    // ── Groq API Key Setup Guide ──────────────────────────────────────────────
    async function showGroqSetupGuide() {
        if (typeof Swal === 'undefined') return;
        const result = await Swal['fire']({
            'title': '🤖 Groq API Key Required',
            'html': '<div style="text-align:left;font-family:Inter,sans-serif;">'
                + '<p style="margin-bottom:14px;color:rgba(199,210,254,0.8);font-size:13px;">'
                + 'ShiftSniper uses <b style="color:#c7d2fe;">Groq AI</b> to automatically solve CAPTCHAs. '
                + 'Get your <b style="color:#c7d2fe;">free</b> API key in 2 minutes:</p>'
                + '<div style="display:flex;flex-direction:column;gap:8px;">'
                + '<div style="background:rgba(34,211,238,0.07);border:1px solid rgba(34,211,238,0.2);border-radius:10px;padding:11px 13px;">'
                + '<div style="font-size:10px;font-weight:700;color:#22d3ee;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;">① Create Free Account</div>'
                + '<div style="font-size:12.5px;color:rgba(199,210,254,0.75);">'
                + 'Visit <a href="https://console.groq.com" target="_blank" style="color:#818cf8;font-weight:600;">console.groq.com</a> → Sign up (free, no credit card)</div></div>'
                + '<div style="background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.2);border-radius:10px;padding:11px 13px;">'
                + '<div style="font-size:10px;font-weight:700;color:#818cf8;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;">② Get Your API Key</div>'
                + '<div style="font-size:12.5px;color:rgba(199,210,254,0.75);">'
                + 'Click <b style="color:#c7d2fe;">API Keys</b> in the sidebar → <b style="color:#c7d2fe;">Create API Key</b> → Copy key starting with '
                + '<code style="background:rgba(99,102,241,0.2);color:#a5f3fc;padding:1px 6px;border-radius:4px;font-size:11px;">gsk_</code></div></div>'
                + '<div style="background:rgba(139,92,246,0.08);border:1px solid rgba(139,92,246,0.2);border-radius:10px;padding:11px 13px;">'
                + '<div style="font-size:10px;font-weight:700;color:#a78bfa;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;">③ Paste in Extension</div>'
                + '<div style="font-size:12.5px;color:rgba(199,210,254,0.75);">'
                + 'Click the <b style="color:#c7d2fe;">ShiftSniper</b> icon in toolbar → Find <b style="color:#c7d2fe;">🤖 Groq API Key</b> → Paste → Saved automatically</div></div>'
                + '</div>'
                + '<p style="margin-top:12px;font-size:11px;color:rgba(199,210,254,0.35);text-align:center;">'
                + 'Without API key, you must solve CAPTCHAs manually every time.</p></div>',
            'showConfirmButton': true,
            'showCancelButton': true,
            'confirmButtonText': '🔗 Open Groq Console',
            'cancelButtonText': '✋ Solve Manually',
            'reverseButtons': false,
            'allowEscapeKey': false,
            'allowOutsideClick': false,
            'icon': 'info'
        });
        if (result && result['isConfirmed']) {
            window.open('https://console.groq.com/keys', '_blank');
        }
        // Either way return — user solves manually or gets key and retries
    }
    // ─────────────────────────────────────────────────────────────────────────

    async function handleCaptcha() {
        await sleep(200);
        // ── Safety net: Begin button must be clicked before grid appears ──────
        const _bbSafe = [...document.querySelectorAll('button')].find(b =>
            /^begin/i.test(b.textContent.trim()) && b.getBoundingClientRect().width > 0);
        if (_bbSafe) {
            console.log('[auth.js] Begin button in handleCaptcha — clicking, waiting for grid');
            _bbSafe.click();
            await sleep(2500);
            _captchaHandling = false;
            return; // captchaWatcher picks up the grid on next 600ms tick
        }
        // ─────────────────────────────────────────────────────────────────────
        console.log('[auth.js] handleCaptcha start', new Date().toLocaleTimeString());

        // ── A: Hybrid CAPTCHA detection ────────────────────────────────────────────
        //
        // Strategy 1 (hiring.amazon.ca pages — contactInformation etc):
        //   CAPTCHA images are regular <img> tags in the main DOM → find them directly,
        //   use exact image centers for clicking (precise, works anywhere).
        //
        // Strategy 2 (auth.hiring.amazon.com — awswaf-captcha web component):
        //   Images live inside shadow DOM → querySelectorAll finds ZERO images.
        //   Fall back to the ORIGINAL modal-rect + ratio approach that worked before.
        //
        // Both strategies are tried every call; the one that produces 6+ images wins.
        // ─────────────────────────────────────────────────────────────────────────────

        // Strategy 1: scan main DOM for CAPTCHA grid images
        const _allImgs = [...document.querySelectorAll('img')].filter(function(img) {
            const r = img.getBoundingClientRect();
            return r.width >= 50 && r.width <= 400 &&
                   r.height >= 50 && r.height <= 400 &&
                   r.top >= 0 && r.top < window.innerHeight - 20 &&
                   img.src && img.src.startsWith('http');
        });
        _allImgs.sort(function(a, b) {
            const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
            const rowA = Math.round(ra.top / 25) * 25;
            const rowB = Math.round(rb.top / 25) * 25;
            return rowA !== rowB ? rowA - rowB : ra.left - rb.left;
        });
        const _gridImgs  = _allImgs.slice(0, 9);
        const _gridRects = _gridImgs.map(function(img) { return img.getBoundingClientRect(); });
        const _hasGrid   = _gridImgs.length >= 6;

        // Compute bounding box of detected images
        var _gTop = 0, _gLeft = 0, _gRight = window.innerWidth, _gBottom = window.innerHeight;
        if (_hasGrid) {
            _gTop    = Math.min.apply(null, _gridRects.map(function(r) { return r.top;    }));
            _gLeft   = Math.min.apply(null, _gridRects.map(function(r) { return r.left;   }));
            _gRight  = Math.max.apply(null, _gridRects.map(function(r) { return r.right;  }));
            _gBottom = Math.max.apply(null, _gridRects.map(function(r) { return r.bottom; }));
        }

        // Strategy 2 fallback: find modal element for auth-page shadow-DOM CAPTCHA
        var modalRect;
        if (_hasGrid) {
            // Image-based: use actual grid boundaries
            modalRect = { top: Math.round(_gTop), left: Math.round(_gLeft),
                          width: Math.round(_gRight - _gLeft), height: Math.round(_gBottom - _gTop) };
            console.log('[auth.js] Strategy 1 (image-based):', _gridImgs.length, 'imgs, rect:', JSON.stringify(modalRect));
        } else {
            // Fallback: awswaf-captcha web component exposes its outer rect (children in shadow DOM)
            var _captchaEl = document.querySelector('awswaf-captcha') ||
                             document.querySelector('[id*="awswaf"]') ||
                             document.querySelector('#captchaModal') ||
                             document.querySelector('.captcha-modal') ||
                             document.querySelector('[class*="captcha"]');
            if (!_captchaEl) {
                console.warn('[auth.js] No CAPTCHA element found — retrying next tick');
                return;
            }
            var _mr = _captchaEl.getBoundingClientRect();
            if (_mr.top < 60) { window.scrollBy(0, _mr.top - 60); await sleep(200); _mr = _captchaEl.getBoundingClientRect(); }
            modalRect = {
                top:    Math.max(0, Math.round(_mr.top)),
                left:   Math.round(_mr.left),
                width:  _mr.width > 700 ? Math.round(window.innerWidth  * 0.24) : Math.round(_mr.width),
                height: _mr.width > 700 ? Math.round(window.innerHeight * 0.82) : Math.round(_mr.height)
            };
            console.log('[auth.js] Strategy 2 (modal fallback / awswaf shadow DOM), rect:', JSON.stringify(modalRect));
        }

        // ── B: Groq key ────────────────────────────────────────────────────────
        let groqKey = '';
        try { groqKey = (await chrome.storage.local.get(['groq_api_key'])).groq_api_key || ''; } catch(_) {}
        // No fallback key — user must enter their own key in the popup
        if (!groqKey) {
            // Guide is shown after PIN entry (in fetch.js) — just remind here
            toast('&#9888; <b style="color:#f59e0b;">No Groq API key!</b> Open the ShiftSniper popup &rarr; AI Captcha Solver &rarr; paste your <span style="color:#22d3ee;font-family:monospace;">gsk_</span> key. Solving manually for now.', 8000);
            return;
        }

        toast('🤖 <b style="color:#ffcc00;">AI solving CAPTCHA — hang tight...</b>', 25000);

        // ── C: Screenshot ──────────────────────────────────────────────────────
        const ssRes = await new Promise(resolve => {
            chrome.runtime.sendMessage({ action: 'takeScreenshot' }, r => {
                if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
                else resolve(r || { error: 'no ss' });
            });
        });
        if (ssRes.error || !ssRes.dataUrl) { toast('❌ Screenshot failed', 4000); return; }

        // ── D: Hybrid crop ─────────────────────────────────────────────────────────
        // Strategy 1 (image-found): crop to grid + 90px above for instruction text
        // Strategy 2 (modal fallback): crop to modal rect with 20px padding (old approach)
        let cropUrl = ssRes.dataUrl;
        try {
            const img = new Image();
            await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = ssRes.dataUrl; });
            const scale = img.naturalWidth / window.innerWidth;
            var sx, sy, sw, sh;
            if (_hasGrid) {
                // Expand upward to include instruction text ("Choose all the ___")
                const _cTop   = Math.max(0, _gTop  - 90);
                const _cLeft  = Math.max(0, _gLeft - 20);
                const _cW     = Math.min(window.innerWidth,  _gRight  + 20) - _cLeft;
                const _cH     = Math.min(window.innerHeight, _gBottom + 20) - _cTop;
                sx = Math.round(_cLeft * scale);
                sy = Math.round(_cTop  * scale);
                sw = Math.min(Math.round(_cW * scale), img.naturalWidth  - sx);
                sh = Math.min(Math.round(_cH * scale), img.naturalHeight - sy);
            } else {
                // Modal rect crop (original approach — works for awswaf shadow DOM)
                const PAD = Math.round(20 * scale);
                sx = Math.max(0, Math.round(modalRect.left  * scale) - PAD);
                sy = Math.max(0, Math.round(modalRect.top   * scale) - PAD);
                sw = Math.min(Math.round(modalRect.width  * scale) + PAD*2, img.naturalWidth  - sx);
                sh = Math.min(Math.round(modalRect.height * scale) + PAD*2, img.naturalHeight - sy);
            }
            const fw = Math.min(sw, 640), fh = Math.round(sh * fw / sw);
            const cv = document.createElement('canvas'); cv.width = fw; cv.height = fh;
            cv.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, fw, fh);
            cropUrl = cv.toDataURL('image/jpeg', 0.90);
            console.log('[auth.js] crop:', fw + 'x' + fh);
        } catch(e) { console.warn('[auth.js] crop failed:', e.message); }

        // ── E: Groq call ── FIX: multi-model fallback (404 on deprecated model) ──
        console.log('[auth.js] calling Groq...');
        let positions = [];
        // ── FIX: compress image + expanded model list + 400 retry with tiny image ──
        // Step 1: 280×280 at 40% quality — big enough for model to see cell contents
        // 160×160 was too small (each cell ~50px) → model confused hat/shoe/bag.
        // 280×280 gives ~90px per cell. max_tokens:1500 + /nothink prevent 413.
        let compCropUrl = cropUrl;
        try {
            const _cimg = new Image();
            await new Promise(function(res, rej) { _cimg.onload = res; _cimg.onerror = rej; _cimg.src = cropUrl; });
            const _maxD = 280;
            const _csc  = Math.min(_maxD / _cimg.naturalWidth, _maxD / _cimg.naturalHeight, 1);
            const _ccv  = document.createElement('canvas');
            _ccv.width  = Math.round(_cimg.naturalWidth  * _csc);
            _ccv.height = Math.round(_cimg.naturalHeight * _csc);
            _ccv.getContext('2d').drawImage(_cimg, 0, 0, _ccv.width, _ccv.height);
            compCropUrl = _ccv.toDataURL('image/jpeg', 0.40);
            var _kb = Math.round(compCropUrl.length / 1024);
            console.log('[auth.js] Compressed:', _ccv.width+'x'+_ccv.height, _kb+'KB');
            // If still large (compress harder — prevents 413)
            if (_kb > 50) {
                var _cv2 = document.createElement('canvas');
                _cv2.width = 200; _cv2.height = Math.round(_ccv.height * 200 / _ccv.width);
                _cv2.getContext('2d').drawImage(_ccv, 0, 0, _cv2.width, _cv2.height);
                compCropUrl = _cv2.toDataURL('image/jpeg', 0.30);
                console.log('[auth.js] Extra-compressed:', Math.round(compCropUrl.length/1024)+'KB');
            }
        } catch(_ce) {
            // Emergency: compress at absolute minimum to avoid sending large raw image
            console.warn('[auth.js] Compress failed — emergency fallback:', _ce.message);
            try {
                var _em = new Image(); var _evLoaded = false;
                await new Promise(function(r) { _em.onload = function(){ _evLoaded=true; r(); }; _em.src = cropUrl; setTimeout(r, 2000); });
                if (_evLoaded) {
                    var _ev = document.createElement('canvas'); _ev.width = 180; _ev.height = 180;
                    _ev.getContext('2d').drawImage(_em, 0, 0, 180, 180);
                    compCropUrl = _ev.toDataURL('image/jpeg', 0.30);
                }
            } catch(_) {}
        }


        // Step 2: Model list — prioritise models visible in user's Groq account (Image 3):
        // openai/gpt-oss-120b, openai/gpt-oss-20b, qwen/qwen3.6-27b are confirmed in account.
        // Llama 4 and Llama 3.2 vision models also tried as fallback.
        // qwen/qwen3.6-27b is Groq's OFFICIAL replacement for Llama 4 Scout (deprecated Jun 2026)
        // It's already in the user's free Groq account and supports image input (vision).
        // Source: console.groq.com/docs/deprecations + console.groq.com/docs/vision
        const _groqModels = [
            'qwen/qwen3.6-27b',                                 // ← PRIMARY: Groq's official replacement for Llama 4 Scout, vision capable, FREE
            'openai/gpt-oss-120b',                              // Groq's replacement for Llama 4 Maverick
            'openai/gpt-oss-20b',                               // Smaller OSS variant
            'llama-4-scout',                                    // Try short ID just in case
            'meta-llama/llama-4-scout-17b-16e-instruct',       // Original full ID
            'llama-3.2-90b-vision-preview',                     // Legacy fallback
            'llama-3.2-11b-vision-preview'
        ];
        // ── Balanced prompt: clear cell layout + direct answer format ─────────────
        // Not too minimal (model guesses) and not too verbose (model runs out of tokens).
        // Cell numbering grid is explicit so model maps positions correctly.
        const _groqPrompt =
            'CAPTCHA grid cells (numbered left→right, top→bottom):\n' +
            '1 2 3\n' +
            '4 5 6\n' +
            '7 8 9\n\n' +
            'Read the instruction in the image ("Choose all the ___").\n' +
            'Identify ONLY cells showing that exact object.\n' +
            'FINAL ANSWER: [e.g. 1,4,7] or FINAL ANSWER: NONE';

        // ── FIX: Route Groq calls via background.js to bypass CORS ──────────────
        // auth.js runs on auth.hiring.amazon.com — direct fetch() to api.groq.com
        // is blocked by CORS policy. Background service worker has no such restriction.
        async function _tryGroqModel(modelId, imgUrl, key) {
            return new Promise(function(resolve) {
                var _timer = setTimeout(function() {
                    resolve({ ok: false, status: 0, _timeout: true });
                }, 25000);
                chrome.runtime.sendMessage({
                    action: 'groqVisionRequest',
                    groqKey: key,
                    model: modelId,
                    imageUrl: imgUrl,
                    prompt: _groqPrompt
                }, function(result) {
                    clearTimeout(_timer);
                    if (chrome.runtime.lastError || !result) {
                        resolve({ ok: false, status: 0 });
                        return;
                    }
                    var _content = result.content || '';
                    // Return a fake Response-like object so existing code works unchanged
                    resolve({
                        ok:     result.status === 200,
                        status: result.status || 0,
                        json:   async function() {
                            return { choices: [{ message: { content: _content } }] };
                        }
                    });
                });
            });
        }
        // ─────────────────────────────────────────────────────────────────────────

        try {
            let gResp = null, usedModel = '';
            for (const _model of _groqModels) {
                try {
                    let _r = await _tryGroqModel(_model, compCropUrl, groqKey);
                    if (_r && _r.ok) { gResp = _r; usedModel = _model; break; }

                    // 429 Rate Limited — stop trying all models immediately (all will be limited)
                    // Wait 25s before allowing the captchaWatcher to retry.
                    if (_r && _r.status === 429) {
                        console.warn('[auth.js] 429 rate limit — waiting 25s before retry');
                        toast('\u23F3 <b style="color:#f59e0b;">Groq rate limited — auto-retrying in 25s...</b>', 26000);
                        await sleep(25000);
                        return; // exit handleCaptcha — watcher will retry after its cooldown
                    }

                    if (_r && _r.status === 404) {
                        console.warn('[auth.js] Model', _model, '\u2192 404, trying next');
                        continue;
                    }
                    if (_r && _r.status === 400) {
                        // 400: try with even tinier image (strict size limit)
                        console.warn('[auth.js] Model', _model, '\u2192 400, retrying at 160px');
                        try {
                            const _ti = new Image();
                            await new Promise(function(res, rej) { _ti.onload = res; _ti.onerror = rej; _ti.src = compCropUrl; });
                            const _tc = document.createElement('canvas');
                            _tc.width = Math.min(_ti.naturalWidth, 160);
                            _tc.height = Math.round(_ti.naturalHeight * (_tc.width / _ti.naturalWidth));
                            _tc.getContext('2d').drawImage(_ti, 0, 0, _tc.width, _tc.height);
                            _r = await _tryGroqModel(_model, _tc.toDataURL('image/jpeg', 0.3), groqKey);
                            if (_r && _r.ok) { gResp = _r; usedModel = _model+'(tiny)'; break; }
                            // 400 tiny also rate limited
                            if (_r && _r.status === 429) {
                                toast('\u23F3 <b style="color:#f59e0b;">Groq rate limited — auto-retrying in 25s...</b>', 26000);
                                await sleep(25000);
                                return;
                            }
                        } catch(_te) {}
                        continue;
                    }
                    gResp = _r; usedModel = _model; break;
                } catch(_me) { console.warn('[auth.js] Model', _model, 'threw:', _me.message); }
            }
            if (!gResp) { toast('\u274C Groq: no working model — solve CAPTCHA manually', 8000); return; }
            // Wrong key (401), server error (500), etc — show correct message
            if (!gResp.ok) {
                var _errMsg = gResp.status === 401
                    ? '\u274C Groq: Invalid API key — check your Groq key in the popup'
                    : '\u274C Groq error ' + gResp.status + ' — try again later';
                toast(_errMsg, 6000);
                return;
            }
            console.log('[auth.js] Groq model used:', usedModel);
            const gData = await gResp.json();
            let resp = (gData.choices && gData.choices[0] && gData.choices[0].message && gData.choices[0].message.content || '').trim();

            // ── FIX: Qwen 3.6 thinking mode wraps reasoning in <think>...</think> ──
            // max_tokens=500 was too small — thinking block consumed all tokens before
            // FINAL ANSWER could be output. Now using 2000 tokens + stripping think tags.
            resp = resp.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();

            console.log('[auth.js] Groq (stripped):', resp.slice(0, 300));

            // Primary parser: look for FINAL ANSWER: X,Y,Z
            const fm = resp.match(/FINAL ANSWER:\s*([0-9][0-9,\s]*|NONE)/i);
            if (fm && fm[1].toUpperCase() !== 'NONE') {
                positions = fm[1].split(/[,\s]+/).map(n => parseInt(n)).filter(n => !isNaN(n) && n >= 1 && n <= 9);
            }
            // Fallback parser: look for "matching cells are X, Y, Z" or "cells are X, Y"
            // (catches responses where FINAL ANSWER format isn't used)
            if (!positions.length) {
                var fallbackMatch = resp.match(/(?:matching cells?|selected cells?|cells? are)[\s:]*([1-9][\s,1-9]*)/i);
                if (fallbackMatch) {
                    positions = fallbackMatch[1].split(/[,\s]+/).map(function(n) { return parseInt(n); }).filter(function(n) { return !isNaN(n) && n >= 1 && n <= 9; });
                    if (positions.length) console.log('[auth.js] Used fallback parser, positions:', positions);
                }
            }
            // Last resort: look for any standalone numbers 1-9 near "yes" or "curtain/bag/clock" etc
            if (!positions.length) {
                var yesMatches = [...resp.matchAll(/Cell\s*(\d):\s*Yes/gi)];
                if (yesMatches.length > 0) {
                    positions = yesMatches.map(function(m) { return parseInt(m[1]); }).filter(function(n) { return n >= 1 && n <= 9; });
                    if (positions.length) console.log('[auth.js] Used Cell:Yes parser, positions:', positions);
                }
            }
        } catch(e) { toast('\u274C Groq error: ' + e.message, 5000); return; }
        if (!positions.length) { console.warn('[auth.js] no positions'); return; }
        console.log('[auth.js] positions:', positions);
        toast('🤖 <b style="color:#4CAF50;">Clicking: ' + positions.join(',') + '</b>', 5000);

        // ── F: Hybrid click coordinates ────────────────────────────────────────────
        // Strategy 1 (image-found): click the exact CENTER of each detected image
        // Strategy 2 (modal fallback): use original modal-rect ratio offsets (awswaf)
        let cellClicks;
        if (_hasGrid && _gridRects.length >= Math.max.apply(null, positions)) {
            // Precise: click the center pixel of each detected grid image
            cellClicks = positions.map(function(pos) {
                const r = _gridRects[pos - 1];
                return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
            });
            console.log('[auth.js] Strategy 1 clicks (image centers):', JSON.stringify(cellClicks));
        } else {
            // Original ratio approach — reliable for awswaf-captcha shadow DOM on auth pages
            const gT = modalRect.top  + modalRect.height * 0.17;
            const gL = modalRect.left + modalRect.width  * 0.03;
            const cW = (modalRect.width  * 0.94) / 3;
            const cH = (modalRect.height * 0.62) / 3;
            cellClicks = positions.map(function(pos) {
                const row = Math.floor((pos-1)/3), col = (pos-1)%3;
                return { x: Math.round(gL + col*cW + cW/2), y: Math.round(gT + row*cH + cH/2) };
            });
            console.log('[auth.js] Strategy 2 clicks (modal ratios):', JSON.stringify(cellClicks));
        }

        // ── G: ONE debugger session — click cells then Confirm via shadow DOM ──
        console.log('[auth.js] sending clickCellsAndConfirm...');
        const result = await new Promise(resolve => {
            chrome.runtime.sendMessage({ action: 'clickCellsAndConfirm', cellClicks }, r => {
                if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
                else resolve(r || { error: 'no response' });
            });
        });
        console.log('[auth.js] clickCellsAndConfirm result:', JSON.stringify(result));

        if (result.error) { toast('❌ ' + result.error, 5000); return; }
        toast('✅ <b style="color:#4CAF50;">Submitted: ' + positions.join(',') + ' | ' + (result.confirmStatus || '?') + '</b>', 5000);

        // ── H: Wait for CAPTCHA outcome (up to 6s) ────────────────────────────
        // Only retry after "Incorrect" is confirmed AND new images are loaded
        console.log('[auth.js] waiting for outcome...');
        let outcome = 'pending';
        for (let w = 0; w < 12; w++) {
            await sleep(500);
            const txt = document.body.innerText;
            if (!document.querySelector('#captchaModal, .captcha-modal, awswaf-captcha')) {
                outcome = 'success'; break;
            }
            if (txt.includes('Incorrect') || txt.includes('incorrect') || txt.includes('try again')) {
                outcome = 'incorrect'; break;
            }
        }
        console.log('[auth.js] outcome:', outcome);

        if (outcome === 'success') {
            toast('🎉 <b style="color:#00d4ff;">CAPTCHA solved — proceeding!</b>', 5000);
            clearInterval(_captchaWatcherInterval);
        } else if (outcome === 'incorrect') {
            // Signal captchaWatcher to sleep 12s instead of 4s
            // This gives Amazon time to refresh with new CAPTCHA images
            window['_ssCaptchaWasIncorrect'] = true;
            console.log('[auth.js] CAPTCHA incorrect — waiting 12s for Amazon to refresh images');
            toast('⚠️ Wrong selection — waiting for fresh CAPTCHA...', 4000);
        }
        // 'pending' (no clear result): normal 4s cooldown, watcher retries
    }
    async function clickConfirm() {
        await sleep(400);
        const btn = [...document.querySelectorAll('button')].find(b => /confirm/i.test(b.textContent));
        if (btn) simulateClick(btn);
    }

    // ── OTP: read from Gmail tab → fill → click Continue ────────────────────────
    // staleOtp: if set, skip this code and wait for a NEW different code (after Resend)
    async function handleOTP(staleOtp) {
        clearInterval(_captchaWatcherInterval);
        _captchaHandling = true;
        console.log('[auth.js] ══ handleOTP START ══', new Date().toLocaleTimeString(), staleOtp ? '| skipping stale:' + staleOtp : '');
        // Clear any stale redirect flag from previous sessions
        chrome.storage.local.remove('_pendingJobRedirect');

        // ── One-time Gmail setup guide (shown only on first OTP encounter) ──────
        // Shown BEFORE the OTP polling starts so the user understands what to do.
        // After clicking "Got it!" the extension continues automatically.
        const _guideData = await new Promise(function(res) {
            chrome.storage.local.get('__gmailGuideShown', function(d) { res(d); });
        });
        if (!_guideData['__gmailGuideShown']) {
            // ── FIX: set flag AFTER user clicks Got it — not before ──────────────
            // Previously set before showing → if page navigated away mid-read, flag
            // was already true, guide never reappeared. Now only marks shown on confirm.
            const _guideResult = await Swal['fire']({
                'title': '📬 One-time Gmail Setup',
                'html':
                    '<div style="text-align:left;font-family:Inter,sans-serif;">' +
                    '<p style="margin-bottom:14px;color:rgba(199,210,254,0.8);font-size:13px;">' +
                    'ShiftSniper reads your Amazon verification code <b style="color:#c7d2fe;">automatically</b> ' +
                    'from Gmail — no manual typing needed. Complete this one-time setup to go fully ' +
                    '<b style="color:#22d3ee;">24/7 automatic</b>.</p>' +
                    '<div style="display:flex;flex-direction:column;gap:8px;">' +

                    '<div style="background:rgba(34,211,238,0.07);border:1px solid rgba(34,211,238,0.2);border-radius:10px;padding:11px 13px;">' +
                    '<div style="font-size:10px;font-weight:700;color:#22d3ee;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;">① Open Gmail in this Chrome</div>' +
                    '<div style="font-size:12.5px;color:rgba(199,210,254,0.75);">Go to <a href="https://mail.google.com" target="_blank" style="color:#818cf8;font-weight:600;">mail.google.com</a> and keep it open in a tab — ' +
                    'the extension reads OTP codes directly from your inbox.</div></div>' +

                    '<div style="background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.2);border-radius:10px;padding:11px 13px;">' +
                    '<div style="font-size:10px;font-weight:700;color:#818cf8;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;">② Log into the right Google account</div>' +
                    '<div style="font-size:12.5px;color:rgba(199,210,254,0.75);">Make sure Gmail is signed in with the same email address as your ' +
                    '<b style="color:#c7d2fe;">Amazon Jobs account</b> — that\'s where Amazon sends the 6-digit code.</div></div>' +

                    '<div style="background:rgba(139,92,246,0.08);border:1px solid rgba(139,92,246,0.2);border-radius:10px;padding:11px 13px;">' +
                    '<div style="font-size:10px;font-weight:700;color:#a78bfa;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:4px;">③ Never close Gmail while hunting</div>' +
                    '<div style="font-size:12.5px;color:rgba(199,210,254,0.75);">ShiftSniper will open Gmail automatically each time it needs a code, ' +
                    'scroll to the <b style="color:#c7d2fe;">latest email</b>, extract the code and fill it in — ' +
                    'completely hands-free.</div></div>' +
                    '</div>' +
                    '<div style="margin-top:13px;padding:10px 13px;background:rgba(22,245,255,0.04);border:1px solid rgba(22,245,255,0.12);border-radius:10px;">' +
                    '<div style="font-size:11.5px;color:rgba(199,210,254,0.6);line-height:1.6;">' +
                    '💡 <b style="color:rgba(199,210,254,0.85);">Pro tip:</b> Pin the Gmail tab so it stays open even after browsing. ' +
                    'This guide will not appear again — you\'re all set after clicking Got it!</div></div>' +
                    '</div>',
                'confirmButtonText': '✅ Got it — start automatic OTP!',
                'showCancelButton': false,
                'allowEscapeKey': false,
                'allowOutsideClick': false,
                'focusConfirm': true,
                'customClass': { 'confirmButton': 'swal-btn-cyan' }
            });
            // Only mark as shown if user actually clicked Got it (not dismissed by page nav)
            if (_guideResult && _guideResult['isConfirmed']) {
                chrome.storage.local.set({ '__gmailGuideShown': true });
            }
            // If dismissed/interrupted: flag stays unset → guide shows again next time
        }
        // ─────────────────────────────────────────────────────────────────────────

        // Step 1: Wait 4s then refresh Gmail once
        toast('📬 <b style="color:#00d4ff;">Waiting for verification email...</b>', 6000);
        await sleep(4000);
        console.log('[auth.js] Refreshing Gmail tab...');
        const _rfResult = await new Promise(resolve => {
            chrome.runtime.sendMessage({ action: 'refreshGmailTab' }, r => resolve(r || {}));
        });
        if (_rfResult && _rfResult.opened) {
            console.log('[auth.js] Gmail tab auto-opened — waiting 7s for load');
            toast('📬 <b style="color:#ffcc00;">Gmail opened — loading your inbox...</b>', 8000);
            await sleep(7000);
        } else {
            await sleep(3000);
        }
        console.log('[auth.js] Gmail ready — polling for OTP...');

        // Step 2: Poll for OTP — if staleOtp given, skip it and wait for a NEW code
        let otp = null;
        for (let i = 0; i < 12 && !otp; i++) {
            const candidate = await fetchOTPFromGmail();
            console.log('[auth.js] OTP poll', i+1, '→', candidate || 'null', staleOtp && candidate === staleOtp ? '(stale, skipping)' : '');
            if (candidate && candidate !== staleOtp) {
                otp = candidate;
            } else if (!candidate) {
                toast('📬 Checking Gmail ' + (i+1) + '/12...', 3200);
                await sleep(3000);
            } else if (candidate === staleOtp && i < 8) {
                // Still seeing the old code — wait for Resend to deliver new email
                toast('📬 Waiting for new code (old: ' + staleOtp + ')...', 3200);
                await sleep(4000);
            }
        }

        if (!otp) {
            console.error('[auth.js] OTP not found after 12 attempts');
            if (typeof Swal !== 'undefined') {
                Swal['fire']({
                    'title': '📬 Gmail Required',
                    'html': '<div style="text-align:left;font-size:14px;">' +
                            '<b>Could not find the OTP in Gmail.</b><br><br>' +
                            'Please make sure:<br>' +
                            '✅ Gmail is open in this browser<br>' +
                            '✅ You are logged into your Amazon account email<br>' +
                            '✅ The Amazon Jobs verification email has arrived<br><br>' +
                            '<small style="color:#aaa;">The extension will retry automatically once Gmail is open.</small>' +
                            '</div>',
                    'icon': 'warning',
                    'confirmButtonText': 'Open Gmail',
                    'showCancelButton': true,
                    'cancelButtonText': "I'll do it manually"
                })['then'](function(result) {
                    if (result['isConfirmed']) {
                        chrome.runtime.sendMessage({ action: 'refreshGmailTab' });
                        setTimeout(function() {
                            _handling = false;
                            handleOTP(staleOtp); // keep skipping the stale code
                        }, 8000);
                    }
                });
            } else {
                toast('❌ <b>Open Gmail tab with your Amazon account to receive OTP</b>', 15000);
            }
            return;
        }
        console.log('[auth.js] ✅ OTP found:', otp);
        toast('✅ <b style="color:#00d4ff;">Code received: ' + otp + ' — filling in...</b>', 4000);

        // Step 3: Find OTP input
        await sleep(500);
        const otpInput = document.querySelector('input[data-test-id="input-test-id-code"]')
                      || document.querySelector('input[data-test-id*="code"]')
                      || document.querySelector('input[maxlength="6"]')
                      || document.querySelector('input[type="text"]');
        console.log('[auth.js] OTP input found:', otpInput ? otpInput.outerHTML.slice(0,80) : 'NOT FOUND');
        if (!otpInput) { toast('❌ OTP input not found', 5000); return; }

        // Step 4: Fill OTP using React native setter
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(otpInput, otp);
        otpInput.dispatchEvent(new Event('input',  { bubbles: true }));
        otpInput.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(500);
        nativeSetter.call(otpInput, otp); // second fill to be sure
        otpInput.dispatchEvent(new Event('input', { bubbles: true }));
        await sleep(500);
        console.log('[auth.js] Input value after fill:', otpInput.value, '| expected:', otp, '| match:', otpInput.value === otp);

        // Step 5: Set redirect flag NOW — before clicking anything
        chrome.storage.local.set({ _pendingJobRedirect: true });
        console.log('[auth.js] ✅ pendingJobRedirect set (pre-click)');

        // Step 6: Click Verify
        const verifyBtn = document.querySelector('button[data-test-id="button-test-id-verifyAccount"]')
                       || [...document.querySelectorAll('button')].find(b => /^verify$/i.test(b.textContent.trim()));
        console.log('[auth.js] Verify button:', verifyBtn ? verifyBtn.getAttribute('data-test-id') : 'NOT FOUND');
        if (verifyBtn) {
            verifyBtn.focus();
            await sleep(200);
            verifyBtn.click();
            console.log('[auth.js] Verify clicked at', new Date().toLocaleTimeString());
            const _fr = await chrome.storage.local.get('__firstRun');
            if (!_fr['__firstRun']) {
                chrome.storage.local.set({ '__showSetupWizard': true });
            }
        } else {
            toast('❌ Verify button not found', 5000);
            return;
        }

        // Step 7: Wait 3s for Continue button
        console.log('[auth.js] Waiting 3s for Continue button...');
        await sleep(3000);
        const continueBtn = document.querySelector('button[data-test-id="button-continue"]')
                         || [...document.querySelectorAll('button')].find(b => /^continue$/i.test(b.textContent.trim()));
        console.log('[auth.js] Continue button:', continueBtn ? continueBtn.getAttribute('data-test-id') : 'NOT FOUND');
        if (continueBtn) {
            continueBtn.focus();
            await sleep(200);
            continueBtn.click();
            console.log('[auth.js] Continue clicked at', new Date().toLocaleTimeString());
        }

        // Step 8: Check for invalid code error → Resend with current OTP as stale
        await sleep(2000);
        const errorMsg = document.body.innerText || '';
        if (/not valid|invalid|expired|try resending/i.test(errorMsg)) {
            console.log('[auth.js] OTP', otp, 'rejected — clicking Resend, will skip this code next time');
            toast('⚠️ <b style="color:#ffcc00;">Code rejected — requesting fresh code...</b>', 5000);
            const resendBtn = document.querySelector('[data-test-id*="resend"], button[class*="resend"]')
                           || [...document.querySelectorAll('button, a')]
                              .find(b => /resend|send.?again|send.?new/i.test(b.textContent));
            if (resendBtn) {
                resendBtn.click();
                console.log('[auth.js] Resend clicked — waiting 6s then retrying with staleOtp:', otp);
                await sleep(6000);
                _handling = false;
                await handleOTP(otp); // ← pass otp as stale so next poll ignores it
                return;
            }
        }
        console.log('[auth.js] OTP flow complete — fetch.js will handle redirect');
    }


    async function fetchOTPFromGmail() {
        return new Promise(resolve => {
            chrome.runtime.sendMessage({ action: 'fetchGmailOTP' }, function(r) {
                if (chrome.runtime.lastError) {
                    console.error('[auth.js] fetchGmailOTP error:', chrome.runtime.lastError.message);
                    resolve(null);
                    return;
                }
                resolve(r && r.otp ? r.otp : null);
            });
        });
    }

    // ── Main loop ─────────────────────────────────────────────────────────────
    let _handling = false;
    let _captchaHandling = false; // separate lock just for CAPTCHA

    async function runStep() {
        if (_handling) return;
        const step = detectStep();
        if (!step || step === 'captcha') return; // CAPTCHA has its own watcher
        _handling = true;
        try {
            console.log('[auth.js] step:', step);
            await sleep(400);
            if      (step === 'begin-captcha') {
                // Click the Begin button so the grid CAPTCHA loads
                const _bb = [...document.querySelectorAll('button')].find(b =>
                    /^begin/i.test(b.textContent.trim()) && b.getBoundingClientRect().width > 0);
                if (_bb) {
                    console.log('[auth.js] Clicking Begin for human verification pre-screen');
                    toast('\uD83E\uDD16 <b>Human verification detected — clicking Begin...</b>', 3000);
                    _bb.click();
                    await sleep(2500); // wait for CAPTCHA grid to appear
                }
            }
            else if (step === 'verify-type') await handleVerifyType();
            else if (step === 'otp')         await handleOTP();
        } finally {
            _handling = false; // reset immediately — no extra wait
        }
    }

    // ── Dedicated CAPTCHA watcher — runs every 600ms, completely independent ──
    async function captchaWatcher() {
        if (_captchaHandling) return;

        // Detect by AWS WAF custom element OR grid images
        const hasWidget = !!document.querySelector('awswaf-captcha, [id*="awswaf"], [class*="awswaf"]');
        const bodyHas   = document.body.innerText.includes('confirm you are human');

        // Image detection: use r.bottom > 50 instead of r.top > 0
        // (modal may be scrolled so row-1 images have negative r.top)
        const imgs = [...document.querySelectorAll('img')].filter(img => {
            const r = img.getBoundingClientRect();
            return r.width  >= 60 && r.width  <= 350 &&
                   r.height >= 60 && r.height <= 350 &&
                   r.bottom > 50 &&  // at least partially visible
                   img.src && img.src.startsWith('http');
        });
        const hasCaptchaImgs = imgs.length >= 6;

        if (hasWidget || bodyHas || hasCaptchaImgs) {
            console.log('[auth.js] CAPTCHA detected! widget:', hasWidget, 'text:', bodyHas, 'imgs:', imgs.length);
            window['_ssCaptchaActive'] = true;
            _captchaHandling = true;
            try {
                await handleCaptcha();
            } finally {
                // ── KEY FIX: wait LONGER when "Incorrect" was received ────────────
                // Old: always 4s → watcher retried on SAME CAPTCHA with cells still highlighted
                //      → 2nd call toggled already-selected cells → wrong submission
                // New: 12s on Incorrect → Amazon refreshes grid with NEW images before retry
                var _incorrectWait = window['_ssCaptchaWasIncorrect'] ? 12000 : 4000;
                window['_ssCaptchaWasIncorrect'] = false; // reset flag
                console.log('[auth.js] captchaWatcher cooldown:', _incorrectWait + 'ms');
                await sleep(_incorrectWait);
                _captchaHandling = false;
                window['_ssCaptchaActive'] = false;
                console.log('[auth.js] captchaWatcher ready for retry');
            }
        }
    }
    const _captchaWatcherInterval = setInterval(captchaWatcher, 600);

    // ── SPA navigation observer ───────────────────────────────────────────────
    const _obs = new MutationObserver(() => { if (!_handling) runStep(); });
    if (document.body) _obs.observe(document.body, { childList: true, subtree: true });

    await sleep(1500); // let fetch.js run first
    await runStep();

    // ── Stuck PIN watchdog ────────────────────────────────────────────────────
    // If stuck on PIN page for > 30 seconds → reload the page (not retry)
    var _lastStep = null;

    setInterval(function() {
        var url = window.location.href;
        if (!url.includes('auth.hiring')) return;

        var bodyText = document.body && document.body.innerText || '';
        var currentStep = null;
        if (bodyText.includes('Enter your personal PIN')) currentStep = 'pin';
        else if (bodyText.includes('verification code has been sent')) currentStep = 'otp';
        else if (bodyText.includes('Where should we send')) currentStep = 'verify-type';
        else if (bodyText.includes('Email or mobile number')) currentStep = 'email';

        if (currentStep === 'pin' && currentStep === _lastStep) {
            // Stuck on PIN for 10s — reload
            console.log('[auth.js] Watchdog: stuck on PIN — reloading page');
            window.location.reload();
            return;
        }

        if (currentStep === _lastStep && currentStep !== null && !_handling) {
            console.log('[auth.js] Watchdog: stuck on', currentStep, '— retrying runStep');
            _handling = false;
            runStep();
        }
        _lastStep = currentStep;
    }, 10000);

    // ── Overall auth flow timeout ─────────────────────────────────────────────
    // If stuck on auth page for > 5 minutes, reload entirely
    setTimeout(function() {
        if (window.location.href.includes('auth.hiring')) {
            console.log('[auth.js] 5-min timeout — reloading auth page');
            window.location.reload();
        }
    }, 5 * 60 * 1000);

})();
