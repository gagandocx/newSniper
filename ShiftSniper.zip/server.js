require('dotenv').config();
const express   = require('express');
const mysql     = require('mysql2/promise');
const cors      = require('cors');
const rateLimit = require('express-rate-limit');
const path      = require('path');
const crypto    = require('crypto');
const stripe    = require('stripe')(process.env.STRIPE_SECRET_KEY);
const app       = express();

app.use('/stripe/webhook', express.raw({ type: 'application/json' }));
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const ADMIN_KEY   = process.env.ADMIN_KEY   || 'Bugguu.1683@1683.com';
const JWT_SECRET  = process.env.JWT_SECRET  || 'change-this';
const SERVER_URL  = process.env.SERVER_URL  || 'https://usvisaserver.zapto.org/amazon-jobs';
const TRIAL_HOURS = 72;
const TOKEN_TTL   = 300;

const pool = mysql.createPool({
  host: 'localhost', user: 'amazon_jobs_user',
  password: process.env.DB_PASSWORD || 'AmazonJobs2024Strong!',
  database: 'amazon_jobs_db', connectionLimit: 10
});

// (Telegram helper defined below)




// ══════════════════════════════════════════════════════════════
// TELEGRAM ALERTS — server sends real-time notifications
// ══════════════════════════════════════════════════════════════
async function sendTelegram(text) {
  const token   = process.env.TELEGRAM_BOT_TOKEN;
  const chat_id = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chat_id) return; // Not configured — skip silently
  try {
    await fetch('https://api.telegram.org/bot' + token + '/sendMessage', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id, text, parse_mode: 'HTML' })
    });
  } catch(e) {
    console.error('[telegram] Send failed:', e.message);
  }
}
// ─────────────────────────────────────────────────────────────


// ══════════════════════════════════════════════════════════════
// EMAIL ALERTS — Resend (ShiftSniper-branded payment receipts)
// ══════════════════════════════════════════════════════════════
async function sendPaymentEmail(email, amount, sessionId) {
  const apiKey = process.env.RESEND_API_KEY;
  const adminEmail = process.env.ADMIN_EMAIL;
  if (!apiKey || !adminEmail) return; // Not configured — skip silently

  const now = new Date().toLocaleString('en-CA', { timeZone: 'America/Toronto' });

  const html = `
  <div style="margin:0;padding:0;background:#0a0a16;font-family:'Segoe UI',Arial,sans-serif;">
    <div style="max-width:480px;margin:0 auto;padding:32px 20px;">
      <div style="background:linear-gradient(135deg,#0f0f23 0%,#1a1a3e 100%);border:1px solid rgba(34,211,238,0.25);border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(34,211,238,0.15);">

        <div style="background:linear-gradient(135deg,#22d3ee 0%,#818cf8 50%,#a855f7 100%);padding:22px 24px;text-align:center;">
          <div style="font-size:26px;font-weight:900;color:#07071c;letter-spacing:1px;">⚡ SHIFTSNIPER</div>
          <div style="font-size:11px;color:rgba(7,7,28,0.7);letter-spacing:2px;text-transform:uppercase;margin-top:2px;">Warehouse Auto-Apply Engine</div>
        </div>

        <div style="padding:28px 24px;">
          <div style="text-align:center;margin-bottom:20px;">
            <div style="display:inline-block;background:rgba(74,222,128,0.12);border:1px solid rgba(74,222,128,0.35);border-radius:50px;padding:6px 18px;font-size:12px;font-weight:700;color:#4ade80;letter-spacing:1px;">
              ✅ PAYMENT RECEIVED
            </div>
          </div>

          <div style="text-align:center;margin-bottom:24px;">
            <div style="font-size:13px;color:rgba(199,210,254,0.55);margin-bottom:4px;">Amount Charged</div>
            <div style="font-size:36px;font-weight:900;color:#22d3ee;">CA$${amount.toFixed(2)}</div>
          </div>

          <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:14px 16px;margin-bottom:16px;">
            <table style="width:100%;font-size:13px;color:rgba(199,210,254,0.85);border-collapse:collapse;">
              <tr>
                <td style="padding:6px 0;color:rgba(199,210,254,0.5);">Customer</td>
                <td style="padding:6px 0;text-align:right;font-weight:600;color:#e2e8f0;">${email}</td>
              </tr>
              <tr style="border-top:1px solid rgba(255,255,255,0.06);">
                <td style="padding:6px 0;color:rgba(199,210,254,0.5);">Plan</td>
                <td style="padding:6px 0;text-align:right;font-weight:600;color:#fb923c;">⭐ Premium (Lifetime)</td>
              </tr>
              <tr style="border-top:1px solid rgba(255,255,255,0.06);">
                <td style="padding:6px 0;color:rgba(199,210,254,0.5);">Session ID</td>
                <td style="padding:6px 0;text-align:right;font-family:monospace;font-size:10px;color:rgba(199,210,254,0.6);word-break:break-all;">${sessionId}</td>
              </tr>
              <tr style="border-top:1px solid rgba(255,255,255,0.06);">
                <td style="padding:6px 0;color:rgba(199,210,254,0.5);">Time</td>
                <td style="padding:6px 0;text-align:right;font-weight:600;color:#e2e8f0;">${now}</td>
              </tr>
            </table>
          </div>

          <div style="text-align:center;font-size:11px;color:rgba(199,210,254,0.4);">
            🎯 User account upgraded to Premium — unlimited 24/7 scanning active
          </div>
        </div>

        <div style="background:rgba(0,0,0,0.25);padding:12px 24px;text-align:center;font-size:10px;color:rgba(199,210,254,0.3);">
          ShiftSniper Admin Notification &middot; usvisaserver.zapto.org
        </div>
      </div>
    </div>
  </div>`;

  try {
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: 'ShiftSniper <onboarding@resend.dev>',
        to: adminEmail,
        subject: '⚡ ShiftSniper Payment — CA$' + amount.toFixed(2) + ' from ' + email,
        html: html
      })
    });
    console.log('[email] Payment receipt sent for', email);
  } catch (e) {
    console.error('[email] Send failed:', e.message);
  }
}
// ─────────────────────────────────────────────────────────────


const apiLimiter      = rateLimit({ windowMs: 60000, max: 120, message: { message: 'Too many requests.' } });
const checkoutLimiter = rateLimit({ windowMs: 60000, max: 10,  message: { message: 'Too many checkout requests.' } });

function signToken(payload) {
  const b64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig  = crypto.createHmac('sha256', JWT_SECRET).update(b64).digest('base64url');
  return b64 + '.' + sig;
}
function verifyToken(token) {
  try {
    const [b64, sig] = token.split('.');
    const expected = crypto.createHmac('sha256', JWT_SECRET).update(b64).digest('base64url');
    if (expected !== sig) return null;
    const p = JSON.parse(Buffer.from(b64, 'base64url').toString());
    return p.exp < Math.floor(Date.now()/1000) ? null : p;
  } catch { return null; }
}

app.get('/', (req, res) => res.json({ status: 'ok', service: 'ShiftSniper API v2' }));

app.get('/get-config', apiLimiter, async (req, res) => {
  const { email, version, fp } = req.query;
  if (!email) return res.status(400).json({ message: 'Email is required' });
  try {
    let [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      const trialExp = new Date(Date.now() + TRIAL_HOURS * 3600000);
      await pool.query(
        'INSERT INTO users (email, credits, is_pro_user, version, trial_started_at, trial_expires_at, is_blocked, created_at) VALUES (?, 100, 0, ?, NOW(), ?, 0, NOW())',
        [email, version || '1.0.0', trialExp]
      );
      await pool.query(
        "INSERT INTO activity_log (email, action, details, created_at) VALUES (?, 'NEW_USER', '72h trial started', NOW())",
        [email]
      );
      // 🔔 Telegram: New user
      sendTelegram(
        '🆕 <b>New User Registered!</b>\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        '👤 Email: <code>' + email + '</code>\n' +
        '⏱ Trial: 72 hours free\n' +
        '📅 Joined: ' + new Date().toLocaleString('en-CA', {timeZone:'America/Toronto'}) + '\n' +
        '━━━━━━━━━━━━━━━━━━'
      );
      [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    }
    const user = rows[0];
    if (version && user.version !== version)
      await pool.query('UPDATE users SET version = ? WHERE email = ?', [version, email]);

    // ── Extension ID Security Check ──────────────────────────────
    const eid = req.query.eid || '';
    const allowedEids = (process.env.ALLOWED_EXT_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
    // Only enforce if whitelist is configured AND an eid was sent
    if (allowedEids.length > 0 && eid && !allowedEids.includes(eid)) {
      await pool.query("UPDATE users SET is_blocked = 1 WHERE email = ?", [email]);
      await pool.query(
        "INSERT INTO activity_log (email, action, details, created_at) VALUES (?, 'BLOCKED_MOD_EXT', ?, NOW())",
        [email, 'Modified ext blocked: ' + eid]
      );
      console.log('[security] Modified extension blocked:', email, '| eid:', eid);
      // 🚨 Telegram: Hack attempt
      sendTelegram(
        '🚨 <b>HACK ATTEMPT BLOCKED!</b>\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        '👤 Email: <code>' + email + '</code>\n' +
        '🔧 Unknown Ext ID: <code>' + eid + '</code>\n' +
        '⛔ Status: Account suspended\n' +
        '📅 Time: ' + new Date().toLocaleString('en-CA', {timeZone:'America/Toronto'}) + '\n' +
        '━━━━━━━━━━━━━━━━━━'
      );
      return res.json({ __canScan: false, __blocked: true, __trialExpired: true, __msg: 'Account suspended. Contact admin.' });
    }
    // Check if already blocked
    if (user.is_blocked === 1) {
      return res.json({ __canScan: false, __blocked: true, __trialExpired: true, __msg: 'Account suspended.' });
    }
    // ─────────────────────────────────────────────────────────────

    const now          = new Date();
    const isPro        = user.is_pro_user === 1;
    const trialExpiry  = user.trial_expires_at ? new Date(user.trial_expires_at) : null;
    const trialExpired = trialExpiry ? trialExpiry < now : false;
    const canScan      = isPro || !trialExpired;
    const trialRemSec  = trialExpiry ? Math.max(0, Math.floor((trialExpiry - now) / 1000)) : (TRIAL_HOURS * 3600);
    const token = signToken({ e: email, p: isPro?1:0, s: canScan?1:0, tr: trialRemSec, fp: fp||'', exp: Math.floor(Date.now()/1000) + TOKEN_TTL });
    await pool.query('UPDATE users SET last_sync = NOW() WHERE email = ?', [email]);
    return res.json({ __cr: user.credits, __isProUser: isPro, __token: token, __trialRemSec: trialRemSec, __trialExpired: !canScan, __canScan: canScan });
  } catch (err) {
    console.error('get-config error:', err.message);
    return res.status(500).json({ message: 'Server error.' });
  }
});

app.post('/verify-token', apiLimiter, (req, res) => {
  const { token, fp } = req.body;
  if (!token) return res.status(400).json({ valid: false });
  const p = verifyToken(token);
  if (!p) return res.json({ valid: false, reason: 'expired' });
  if (fp && p.fp && p.fp !== fp) return res.json({ valid: false, reason: 'device_mismatch' });
  return res.json({ valid: true, canScan: p.s===1, isPro: p.p===1, trialRem: p.tr, expiresIn: p.exp - Math.floor(Date.now()/1000) });
});

app.post('/set-credits', apiLimiter, async (req, res) => {
  const { email, version, credits } = req.body;
  if (!email || email === 'null' || email === 'undefined' || !email.includes('@')) {
    return res.status(400).json({ ok: false });
  }
  if (!email) return res.status(400).json({ message: 'Email is required' });
  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      await pool.query(
        'INSERT INTO users (email, credits, is_pro_user, version, trial_started_at, trial_expires_at, created_at) VALUES (?, ?, 0, ?, NOW(), DATE_ADD(NOW(), INTERVAL 72 HOUR), NOW())',
        [email, credits ?? 100, version || '1.0.0']
      );
      return res.json({ __cr: credits ?? 100, __host: SERVER_URL, __sync: 5 });
    }
    const user = rows[0];
    const newC = (credits !== undefined && credits < user.credits) ? credits : user.credits;
    if (newC < user.credits)
      await pool.query("INSERT INTO activity_log (email, action, details, created_at) VALUES (?, 'CREDIT_USED', ?, NOW())", [email, user.credits + ' -> ' + newC]);
    await pool.query('UPDATE users SET credits = ?, version = ?, last_sync = NOW() WHERE email = ?', [newC, version || user.version, email]);
    return res.json({ __cr: newC, __host: SERVER_URL, __sync: (Math.floor(Math.random()*6)+5) });
  } catch (err) { return res.status(500).json({ message: 'Sync failed' }); }
});

app.post('/stripe/create-checkout', checkoutLimiter, async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ message: 'Email required' });
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      customer_email: email,
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      mode: 'payment',
      success_url: SERVER_URL + '/payment-success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url:  SERVER_URL + '/payment-cancel',
      metadata: { email: email },
      client_reference_id: email
    });
    res.json({ url: session.url });
  } catch (err) { res.status(500).json({ message: 'Payment setup failed: ' + err.message }); }
});

app.post('/stripe/webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try { event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET); }
  catch (err) { return res.status(400).send('Webhook Error: ' + err.message); }
  if (event.type === 'checkout.session.completed') {
    const s = event.data.object;
    // Only process ShiftSniper payments — ignore Niken Visa or other products
    try {
      const lineItems = await stripe.checkout.sessions.listLineItems(s.id);
      const paidPriceId = lineItems.data[0]?.price?.id;
      if (paidPriceId && paidPriceId !== process.env.STRIPE_PRICE_ID) {
        console.log('[webhook] Ignored — not ShiftSniper payment, price:', paidPriceId);
        return res.json({ received: true });
      }
    } catch(e) { console.log('[webhook] price check error:', e.message); }
    const email = s.customer_email || (s.metadata && s.metadata.email) || s.client_reference_id;
    if (email) {
      await pool.query(
        "UPDATE users SET is_pro_user=1, credits=99999, trial_expires_at='2037-12-31 23:59:59', stripe_customer_id=?, stripe_session_id=? WHERE email=?",
        [s.customer||null, s.id, email]
      );
      await pool.query(
        "INSERT INTO payments (email,amount,plan,notes,stripe_session_id,created_at) VALUES (?,?,'premium','Stripe payment',?,NOW())",
        [email, (s.amount_total||0)/100, s.id]
      );
      await pool.query(
        "INSERT INTO activity_log (email,action,details,created_at) VALUES (?,'STRIPE_PAYMENT',?,NOW())",
        [email, '$' + ((s.amount_total||0)/100) + ' — Premium activated']
      );
      console.log('[stripe] Upgraded:', email);
      // 💰 Telegram: Payment received
      sendTelegram(
        '💰 <b>PAYMENT RECEIVED!</b>\n' +
        '━━━━━━━━━━━━━━━━━━\n' +
        '👤 Email: <code>' + email + '</code>\n' +
        '💵 Amount: CA$' + ((s.amount_total||0)/100).toFixed(2) + '\n' +
        '🏆 Status: Upgraded to <b>PREMIUM</b>\n' +
        '🔑 Session: ' + s.id + '\n' +
        '📅 Time: ' + new Date().toLocaleString('en-CA', {timeZone:'America/Toronto'}) + '\n' +
        '━━━━━━━━━━━━━━━━━━'
      );
      // 📧 Email: Payment receipt (ShiftSniper-branded)
      sendPaymentEmail(email, (s.amount_total||0)/100, s.id);
    }
  }
  res.json({ received: true });
});


// ─────────────────────────────────────────────────────────────
// JOB FOUND — extension calls this when a matching shift is found
// Server logs it + sends Telegram notification with full details
// ─────────────────────────────────────────────────────────────
// Server-side dedup: prevent same jobId from sending duplicate Telegram alerts
// Extension already deduplicates on client side, this is a second safety layer
const _recentJobAlerts = new Map(); // jobId → timestamp (5-min TTL)

app.post('/job-found', apiLimiter, async (req, res) => {
  const { email, job, jobId, jobTitle, city, jobUrl, country, schedules } = req.body;
  // Normalize: support both old {job:{...}} and new flat {jobId,...} format
  const _j = job || {};
  const _jobId    = jobId    || _j.jobId    || '';
  const _jobTitle = jobTitle || _j.jobTitle || _j.externalJobTitle || 'Warehouse Associate';
  const _city     = city     || _j.city     || '';
  const _state    = _j.state || '';
  const _address  = _j.address || '';
  const _basePay  = (schedules && schedules[0] && schedules[0].basePay) || _j.basePay || _j.totalPayRate || 'N/A';
  const _schedules = schedules || (_j.scheduleText ? [_j] : []);
  const _jobUrl   = jobUrl || ('https://hiring.amazon.ca/app#/jobDetail?jobId=' + _jobId + '&locale=en-CA');
  if (!jobId && !email) return res.status(400).json({ message: "Missing data" });
  try {
    const domain = 'hiring.amazon.ca';
    const jobUrl = 'https://' + domain + '/app#/jobDetail?jobId=' + (_jobId || '') + '&locale=en-CA';
    // ── Server-side dedup check ────────────────────────────────────────────────
    const _now = Date.now();
    const _lastAlert = _recentJobAlerts.get(_jobId);
    if (_lastAlert && (_now - _lastAlert) < 300000) {
      console.log('[job-found] Dedup: skipping duplicate alert for', _jobId);
      return res.json({ ok: true, dedup: true });
    }
    _recentJobAlerts.set(_jobId, _now);
    if (_recentJobAlerts.size > 100) { // prevent memory leak
      const _oldKey = _recentJobAlerts.keys().next().value;
      _recentJobAlerts.delete(_oldKey);
    }
    // ─────────────────────────────────────────────────────────────────────────
    // Log to DB
    await pool.query(
      "INSERT INTO activity_log (email, action, details, created_at) VALUES (?, 'JOB_FOUND', ?, NOW())",
      [(email || 'system'), JSON.stringify({ jobId: _jobId, title: _jobTitle, city: _city, pay: _basePay })]
    );
    // 🎯 Telegram notification with all job details
    const msg =
      '🎯 <b>SHIFT FOUND!</b>\n' +
      '━━━━━━━━━━━━━━━━━━\n' +
      
      '💼 Job: <b>' + (_jobTitle) + '</b>\n' +
      '📍 City: ' + (_city || 'N/A') + (_state ? ', ' + _state : '') + '\n' +
      (_address ? '🏠 Address: ' + _address + '\n' : '') +
      '💰 Pay: <b>' + (_basePay) + '</b>\n' +
      ((_schedules[0] && _schedules[0].hoursPerWeek) ? '⏰ Hours: ' + (_schedules[0] && _schedules[0].hoursPerWeek) + ' hrs/week\n' : '') +
      ((_schedules[0] && _schedules[0].scheduleText) ? '📅 Schedule: ' + (_schedules[0] && _schedules[0].scheduleText) + '\n' : '') +
      ((_schedules[0] && _schedules[0].employmentType) ? '📋 Type: ' + (_schedules[0] && _schedules[0].employmentType) + '\n' : '') +
      ((_schedules[0] && (_schedules[0].firstDayOnSite || _schedules[0].hireStartDate)) ? '🗓 Start Date: ' + (_schedules[0] && (_schedules[0].firstDayOnSite || _schedules[0].hireStartDate)) + '\n' : '') +
      ((_schedules[0] && _schedules[0].signOnBonus) ? '🎁 Sign-on Bonus: ' + (_schedules[0] && _schedules[0].signOnBonus) + '\n' : '') +
      '🔗 <a href="' + jobUrl + '">View Job</a>\n' +
      '━━━━━━━━━━━━━━━━━━\n' +
      '⚡ Auto-applying now...';
    await sendTelegram(msg);
    res.json({ ok: true });
  } catch (err) {
    console.error('job-found error:', err.message);
    res.status(500).json({ message: 'Error' });
  }
});
// ─────────────────────────────────────────────────────────────────

app.get('/payment-success', (req, res) => res.send('<!DOCTYPE html><html><head><title>Premium Active!</title><style>body{background:#07071c;color:#fff;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;text-align:center}.c{background:rgba(22,245,255,.06);border:1px solid rgba(22,245,255,.3);border-radius:24px;padding:48px 40px;max-width:440px}h1{color:#22d3ee}.b{display:inline-block;background:linear-gradient(135deg,#16f5ff,#a341ff);border-radius:20px;padding:8px 24px;font-weight:900;margin:16px 0}p{color:rgba(199,210,254,.8);font-size:14px;line-height:1.6}</style></head><body><div class="c"><div style="font-size:56px;margin-bottom:16px">🎯</div><h1>You are Premium!</h1><div class="b">✦ SHIFTSNIPER PREMIUM ✦</div><p>Payment confirmed! Open ShiftSniper — your Premium badge is now active.</p><p style="font-size:12px;color:rgba(199,210,254,.4);margin-top:16px">You can close this tab.</p></div></body></html>'));
app.get('/payment-cancel', (req, res) => res.send('<!DOCTYPE html><html><head><title>Cancelled</title><style>body{background:#07071c;color:#fff;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;text-align:center}.c{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:24px;padding:48px 40px;max-width:400px}h1{color:rgba(199,210,254,.8)}p{color:rgba(199,210,254,.5);font-size:14px}</style></head><body><div class="c"><div style="font-size:48px;margin-bottom:16px">↩</div><h1>Payment Cancelled</h1><p>No charge was made. Upgrade anytime from the ShiftSniper popup.</p></div></body></html>'));

function adminAuth(req, res, next) {
  const key = req.headers['x-admin-key'] || req.body.key || req.query.key;
  if (key !== ADMIN_KEY) return res.status(403).json({ message: 'Forbidden' });
  next();
}

app.get('/admin/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));

app.get('/admin/stats', adminAuth, async (req, res) => {
  try {
    const [[total]]        = await pool.query('SELECT COUNT(*) as count FROM users');
    const [[proUsers]]     = await pool.query('SELECT COUNT(*) as count FROM users WHERE is_pro_user=1');
    const [[trialActive]]  = await pool.query('SELECT COUNT(*) as count FROM users WHERE trial_expires_at > NOW() AND is_pro_user=0');
    const [[trialExpired]] = await pool.query('SELECT COUNT(*) as count FROM users WHERE trial_expires_at <= NOW() AND is_pro_user=0');
    const [[revenue]]      = await pool.query('SELECT COALESCE(SUM(amount),0) as total FROM payments');
    const [[activeToday]]  = await pool.query('SELECT COUNT(*) as count FROM users WHERE last_sync >= DATE_SUB(NOW(), INTERVAL 24 HOUR)');
    const [[newToday]]     = await pool.query('SELECT COUNT(*) as count FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)');
    const [userGrowth]     = await pool.query('SELECT DATE(created_at) as date, COUNT(*) as count FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY date ASC');
    const [creditActivity] = await pool.query("SELECT DATE(created_at) as date, COUNT(*) as count FROM activity_log WHERE action='CREDIT_USED' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY date ASC");
    res.json({ totalUsers: total.count, proUsers: proUsers.count, trialActive: trialActive.count, trialExpired: trialExpired.count, totalRevenue: revenue.total, activeToday: activeToday.count, newToday: newToday.count, userGrowth, creditActivity });
  } catch (err) { res.status(500).json({ message: 'Stats error' }); }
});

app.get('/admin/users', adminAuth, async (req, res) => {
  try {
    const search = req.query.search || '', filter = req.query.filter || 'all';
    let query = 'SELECT * FROM users WHERE 1=1', params = [];
    if (search)               { query += ' AND email LIKE ?'; params.push('%'+search+'%'); }
    if (filter === 'pro')     query += ' AND is_pro_user=1';
    if (filter === 'trial')   query += ' AND trial_expires_at > NOW() AND is_pro_user=0';
    if (filter === 'expired') query += ' AND trial_expires_at <= NOW() AND is_pro_user=0';
    if (filter === 'active')  query += ' AND last_sync >= DATE_SUB(NOW(), INTERVAL 24 HOUR)';
    query += ' ORDER BY created_at DESC';
    const [rows] = await pool.query(query, params);
    res.json(rows);
  } catch (err) { res.status(500).json({ message: 'Error' }); }
});

app.post('/admin/set-pro', adminAuth, async (req, res) => {
  const { email, isPro } = req.body;
  await pool.query("UPDATE users SET is_pro_user=?, trial_expires_at=? WHERE email=?", [isPro?1:0, isPro?'2037-12-31 23:59:59':new Date(), email]);
  await pool.query("INSERT INTO activity_log (email,action,details,created_at) VALUES (?,'ADMIN_SET_PRO',?,NOW())", [email,'Admin set pro='+isPro]);
  res.json({ message: email+' pro: '+isPro });
});

app.post('/admin/unblock', adminAuth, async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ message: 'Email required' });
  await pool.query("UPDATE users SET is_blocked = 0 WHERE email = ?", [email]);
  await pool.query("INSERT INTO activity_log (email,action,details,created_at) VALUES (?,'ADMIN_UNBLOCK','Admin unblocked user',NOW())", [email]);
  res.json({ message: email + ' unblocked successfully' });
});

app.post('/admin/add-credits', adminAuth, async (req, res) => {
  const { email, credits } = req.body;
  if (!email || !credits) return res.status(400).json({ message: 'Email and credits required' });
  await pool.query('UPDATE users SET credits=credits+? WHERE email=?', [credits, email]);
  await pool.query("INSERT INTO activity_log (email,action,details,created_at) VALUES (?,'ADMIN_ADD_CREDITS',?,NOW())", [email,'Admin added '+credits+' credits']);
  res.json({ message: 'Added '+credits+' to '+email });
});

app.post('/admin/set-credits', adminAuth, async (req, res) => {
  const { email, credits } = req.body;
  await pool.query('UPDATE users SET credits=? WHERE email=?', [credits, email]);
  res.json({ message: 'Credits set to '+credits });
});

app.delete('/admin/delete-user', adminAuth, async (req, res) => {
  const { email } = req.body;
  await pool.query('DELETE FROM users WHERE email=?', [email]);
  await pool.query('DELETE FROM activity_log WHERE email=?', [email]);
  res.json({ message: 'Deleted '+email });
});

app.get('/admin/activity', adminAuth, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM activity_log ORDER BY created_at DESC LIMIT 200');
  res.json(rows);
});

app.get('/admin/payments', adminAuth, async (req, res) => {
  const [rows]    = await pool.query('SELECT * FROM payments ORDER BY created_at DESC');
  const [[total]] = await pool.query('SELECT COALESCE(SUM(amount),0) as total FROM payments');
  res.json({ payments: rows, totalRevenue: total.total });
});

app.post('/admin/add-payment', adminAuth, async (req, res) => {
  const { email, amount, plan, notes } = req.body;
  await pool.query('INSERT INTO payments (email,amount,plan,notes,created_at) VALUES (?,?,?,?,NOW())', [email, amount, plan, notes||'']);
  await pool.query("UPDATE users SET is_pro_user=1, credits=99999, trial_expires_at='2037-12-31 23:59:59' WHERE email=?", [email]);
  await pool.query("INSERT INTO activity_log (email,action,details,created_at) VALUES (?,'MANUAL_PAYMENT',?,NOW())", [email,'$'+amount+' — '+plan]);
  res.json({ message: 'Payment recorded, user upgraded' });
});

app.listen(4000, () => console.log('ShiftSniper API v2 running on port 4000'));

setInterval(async () => {
  try {
    await pool.query('DELETE FROM activity_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)');
    const [[ct]] = await pool.query('SELECT COUNT(*) as c FROM activity_log');
    if (ct.c > 1000) await pool.query('DELETE FROM activity_log ORDER BY created_at ASC LIMIT ?', [ct.c - 1000]);
  } catch(e) { console.error('Cleanup error:', e.message); }
}, 86400000);

app.get('/privacy', (req, res) => res.send(`<!DOCTYPE html><html><head><title>ShiftSniper Privacy Policy</title><style>body{font-family:Arial,sans-serif;max-width:800px;margin:40px auto;padding:20px;line-height:1.6}h1{color:#333}h2{color:#555}</style></head><body><h1>ShiftSniper Privacy Policy</h1><p><strong>Last updated: May 27, 2026</strong></p><h2>Information We Collect</h2><p>ShiftSniper collects only your Amazon Jobs account email address for license verification and trial management. We do not collect passwords, personal information, or browsing history.</p><h2>How We Use Information</h2><p>Your email is used solely to: manage your free trial period, verify premium access, and provide support. We never sell or share your data with third parties.</p><h2>Data Storage</h2><p>Your email and license status are stored securely on our server. Your Amazon account credentials are stored locally in your browser only and never transmitted to our servers.</p><h2>Third Party Services</h2><p>We use Stripe for payment processing and Groq AI for optional CAPTCHA solving. These services have their own privacy policies.</p><h2>Contact</h2><p>Email: harshil.hub@gmail.com</p></body></html>`));
